# Pickr2.0
Pickr is an existing application created for the Kodiak Island School District. The original source code is at https://github.com/miketay/kodiak-picker.


## Getting Started

1. Once downloaded, install dependencies

    $ npm install

2. To start the electron application

    $ npm start

3. To package the application (It will create a folder, inside is the packaged applicaiton)

    $ npm run build