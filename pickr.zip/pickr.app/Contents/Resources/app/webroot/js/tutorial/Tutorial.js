(function() {
	'use strict';

	angular.module('Tutorial', ['ngMaterial', 'ngMessages']);
})();

