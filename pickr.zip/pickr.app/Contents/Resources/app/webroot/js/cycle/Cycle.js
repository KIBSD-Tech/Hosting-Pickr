(function() {
	'use strict';

	angular.module('Cycle', ['ngMaterial', 'ngMessages', 'Tutorial']);
})();

