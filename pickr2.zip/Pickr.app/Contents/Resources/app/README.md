# Pickr2.0
Pickr is an existing application created for the Kodiak Island Borough School District. The original source code is at https://github.com/miketay/kodiak-picker.

Pickr2.0 is a modified application created for distribution by Kodiak Island Borough School District by Carnegie Mellon University Information Systems students. Hosted at https://kibsd-tech.github.io/Hosting-Pickr2/ for direct download. 


## Getting Started

1. Once downloaded, install dependencies

    $ npm install

2. To start the electron application

    $ npm start

3. To package the application (It will create a folder, inside is the packaged applicaiton)

    $ npm run build
    
4. To delete the build, delete all files and the directory. 

