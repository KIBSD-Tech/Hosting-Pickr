(function() {
	'use strict';

	angular.module('Page', ['ngMaterial', 'ngMessages', 'Student', 'Cycle']);
})();
