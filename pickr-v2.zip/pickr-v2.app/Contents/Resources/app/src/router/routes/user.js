module.exports = (localApp, db) => {


}